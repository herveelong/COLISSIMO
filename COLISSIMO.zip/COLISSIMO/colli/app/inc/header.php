<header class="w-100 bg-white d-flex flex-row justify-content-start align-items-center px-2 py-3">
    <div class="w-100 d-flex flex-row justify-content-between align-items-center">
    <div class="d-flex flex-row justify-content-start">
        <img class="bidden-m" src="assets/images/humb.png" alt="" srcset="">
        <img class="bidden-m" src="assets/images/logo-part-23-mobile.svg" alt="" srcset="">
        <img class="bidden" src="assets/images/logo-part-23.svg" alt="" srcset="">
    </div>
    <div>
        <img class="bidden-m" src="assets/images/heads-mob.png" alt="" srcset="">
        <img class="bidden" src="assets/images/heads.png" alt="" srcset="">
    </div>
    </div>
</header>