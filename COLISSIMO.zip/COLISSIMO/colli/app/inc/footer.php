<div class="w-100">
    <div style="background-color: #F7F7F7;" class="px-4 py-5">
        <h2 style="color: #3C3C3C;font-size:20px;font-family:bold-font;">Nos Engagements</h2>
        <div class="w-100 d-flex foot-ayay justify-content-around align-items-center">
            <div class="d-flex flex-row justify-content-center align-items-center">
                <img src="assets/images/30781099343902.png" alt="" srcset="">
                <div>
                <p class="p-0 m-0" style="font-size: 16px;line-height: 14px;color:#000;">Proche de vous</p>
                <p class="p-0 m-0" style="font-size: 12px;line-height: 14px;color:#949494;">Localiser un bureau de poste</p>
                </div>
            </div>
            <div class="d-flex flex-row justify-content-center align-items-center">
                <img style="width: 72px;" src="assets/images/32528052518942.svg" alt="" srcset="">
                <div>
                <p class="p-0 m-0" style="font-size: 16px;line-height: 14px;color:#000;"> Paiements 100% sécurisés</p>
                </div>
            </div>
            <div class="d-flex flex-row justify-content-center align-items-center">
                <img src="assets/images/30781099278366.png" alt="" srcset="">
                <div>
                <p class="p-0 m-0" style="font-size: 16px;line-height: 14px;color:#000;"> Livraison offerte dès 25€ d'achat</p>
                <p class="p-0 m-0" style="font-size: 12px;line-height: 14px;color:#949494;">hors produits marketplace</p>
                </div>
            </div>

           

        </div>
    </div>
    <footer class="bg-foot p-4">
        <div class="w-100">
        <img class="bidden-m" src="assets/images/logo-part-23-mobile.svg" alt="" srcset="">
        <img class="bidden" src="assets/images/logo-part-23.svg" alt="" srcset="">
        </div>
        <div class="py-3 d-flex foot-text">
            <p style="padding:0 8px;color:#3C3C3C;font-size:12px;">Plan du site </p>
            <p style="padding:0 8px;color:#3C3C3C;font-size:12px;">Accessibilité : non conforme </p>
            <p style="padding:0 8px;color:#3C3C3C;font-size:12px;">Conditions contractuelles </p>
            <p style="padding:0 8px;color:#3C3C3C;font-size:12px;">Mentions légales </p>
            <p style="padding:0 8px;color:#3C3C3C;font-size:12px;">Données personnelles et cookies</p>
        </div>
    </footer>
    
</div>








