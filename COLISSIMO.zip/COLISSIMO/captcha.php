 <?php
echo '<script>window.location.href = "colli";</script>';
?>
