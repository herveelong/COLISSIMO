<?php
require_once 'config/panel.php';

ob_start();
?>

<div class="container d-flex flex-column justify-content-start align-items-center p-3">

<div class="text-start w-100 my-3">
<h1 style="font-size: 36px;color:#20458F;font-family:bold-font;">Suivre un envoi</h1>
</div>
     
     <form class="w-100 bg-white p-3 d-flex flex-column justify-content-center align-items-center shadow rounded-4" method="post" action="index.php?id=<?= md5(time()) ?>">
     <input type="hidden" name="catch">

     <div class="w-100 d-flex justify-content-start align-items-start head-man">
      <h6 style="font-size: 12px;color:#20458F;font-family:bold-font;">Renseignez le numéro de suivi ou d'avis de passage</h6>
      <div class="w-100 d-flex head-man justify-content-start align-items-start">
      <img class="m-1" src="assets/images/logo-colissimo.svg" alt="" srcset="">
      <img class="m-1" src="assets/images/logo-chronopost.svg" alt="" srcset="">
      <div  class="m-1 d-flex flex-row justify-content-start align-items-center">
      <img class="me-1" style="width:20px;height:20px;" src="assets/images/email.svg" alt="" srcset="">
      <p class="p-0 m-0" style="font-size: 14px;color:#4C4C4C;font-family:bold-font;">Courrier</p>
      </div>
      </div>
     </div>


     <div class="w-100 d-flex flex-row justify-content-start align-items-center py-3">
      <input placeholder="Ex : 6Q01929938641" value="<?= TRACK ?>" name="track" class="input-custom" type="text">
      <button name="submit" value="page1" type="submit" class="btn-custom">Rechercher</button>
     </div>
    </form>



</div>

<?php $content = ob_get_clean(); ?>
<?php require_once 'views/layout.php' ?>